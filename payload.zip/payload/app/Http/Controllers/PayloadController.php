<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Models\loaddata;
use DB;

class PayloadController extends Controller
{
     //user creation
     public function user_creation(Request $request)
     {
      
       $data = array();
       $response = array();
       $response['status'] = 0;
       $response['msg'] = 'Invalid Parameter parsed';  
       $response['params'] = array();
 
        foreach ($request['params'] as $row) {
        
         //Value Assigning Section Process
         $record['email'] = $row['email'];
         $record['password'] = bcrypt($row['password']); 
         $record['name'] = isset($row['name']) ?  $row['name'] :0;       
               
 
         if (isset($row['remote_id']) && $row['remote_id'] != "0") {
           
          //Validation Field for Duplicate Check Process
           $master_count = User::select('id')->where(
             'email','=', $row['email'])
            ->Where('id','!=', $row['remote_id'])  
            ->get()->count();
         } else {
        
           $master_count = User::select('id')->where(
             'email','=', $row['email'])
            ->get()->count();              
         }
        
         if ($master_count > 0) {
         
            $data[] = array(
                "email" => $row['email'],
               "msg" => 'email Already Exists'
           );
 
           $response['params'] = $data;
           continue;
        } 
 
               //Update Receord Process
               if (isset($row['remote_id']) && $row['remote_id'] != "0") {
               //  $record['m_time'] =   date('Y-m-d H:i:s');
               
 
                   $update= User::where('id', ($row['remote_id']))->update($record);;
 
                   if ($update) {
                       $data[] = array(
                           "id" => $row['id'],
                           "remote_id" => $row['remote_id'],
                           "msg" => 'Updated',
                          
                       );
                   }
 
               } else { 
 
                 //Insert Record Process
                 $record['c_time'] =   date('Y-m-d H:i:s');
             
                 $user=User::create($record);
                   
                  
                 if ($user) {
                      
                  //   $id = $user['id'];
 
                     $data[] = array(
                         //  "id" => $row['id'],
                           //"remote_id" => $id,
                           "msg" => 'Inserted'
                       );
                   } else if (!$result) {
                       
                     $data[] = array(
                           "id" => $row['id'],
                           "remote_id" => 0
                       );
                  }
                 
                }
 
               $response['status'] = 1;
               $response['msg'] = 'Completed';
               $response['params'] = $data;   
                            
          }
               
        return $response;
     }
   
     public function date_creation(Request $request)
     {
      
       $data = array();
       $response = array();
       $response['status'] = 0;
       $response['msg'] = 'Invalid Parameter parsed';  
       $response['params'] = array();
 
        foreach ($request['params'] as $row) {
        
         //Value Assigning Section Process
         $record['date'] = $row['date'];
                       
 
         if (isset($row['remote_id']) && $row['remote_id'] != "0") {
           
          //Validation Field for Duplicate Check Process
           $master_count = loaddata::select('id')->where(
             'date','=', $row['date'])
            ->Where('id','!=', $row['remote_id'])  
            ->get()->count();
         } else {
        
           $master_count = loaddata::select('id')->where(
             'date','=', $row['date'])
            ->get()->count();              
         }
        
         if ($master_count > 0) {         
       
           $data[] = array(
               "date" => $row['date'],
               "msg" => 'date Already Exists'
           );
 
           $response['params'] = $data;
           continue;
        } 
 
               //Update Receord Process
               if (isset($row['remote_id']) && $row['remote_id'] != "0") {
               //  $record['m_time'] =   date('Y-m-d H:i:s');
               
 
                   $update= loaddata::where('id', ($row['remote_id']))->update($record);;
 
                   if ($update) {
                       $data[] = array(
                           "id" => $row['id'],
                           "remote_id" => $row['remote_id'],
                           "msg" => 'Updated',
                          
                       );
                   }
 
               } else { 
 
                 //Insert Record Process
                 $record['c_time'] =   date('Y-m-d H:i:s');
             
                 $user=loaddata::create($record);
                   
                  
                 if ($user) {
                      
                  //   $id = $user['id'];
 
                     $data[] = array(
                         //  "id" => $row['id'],
                           //"remote_id" => $id,
                           "msg" => 'Inserted'
                       );
                   } else if (!$result) {
                       
                     $data[] = array(
                           "id" => $row['id'],
                           "remote_id" => 0
                       );
                  }
                 
                }
 
               $response['status'] = 1;
               $response['msg'] = 'Completed';
               $response['params'] = $data;   
                            
          }
               
        return $response;
     }
   
 
     //login creation
      public function login(Request $request)
     {
       
        $data = array();       
 
        $validateData=$request->validate([ 
      
           'params.*.email' => 'required',
           'params.*.password' => 'required',
            
          ]);
           
 
        $cred = request(['email', 'password']);   
 
         if(!auth()->attempt($cred))
        {
         return response()->json([
           'status' => '0',
           'log_status' => 'login failed'
         ]);
 
        }   
 
       
        $user = User::where('email', request('email'))->first();
 
        $tokenres = $user->createToken('authToken')->plainTextToken;
 
         User::where('id', $user->id)
        ->update([
            'status' => 1
         ]);
 
          $data[] = auth()->user();
           
          //  $u_data = $user_data;
 
           return response()->json([
         
             'status' => '1',
             'msg' => 'login successfully',
             'token' => $tokenres,
             'params'=>$data,
 
 
           ]);        
                   
     }
     public function is_business_day(Request $request)
     { 
                
        if($request->date!=""){
 
            $day_check=DB::table('loaddata')->select('date'); 
         
                $users = $day_check->where('date','=',$request->date)->get();
                if(count($users) > 0){
                    return response([                
                        "status_code" => '200',
                        "data"=>array('is_business_days'),               
                        
                    ]);
                }else
                {
                    return response([                
                        "Data" => 'No Record',
                                       
                        
                    ]);
                }
     
              }    

             else{
               
                return response([                
                    "status" => '0',
                    "msg"=>"No Record",
                               
                    
                ]);
          
             }
            
        }
 
     public function get_business_days(Request $request)
     { 
             
      //  $response['params'] = array();  

        if($request->start_date!=""){
 
         $get_days=DB::table('loaddata')->select('date'); 
      
             $users = $get_days->where('date','>',$request->start_date)->get();
  
           }     
        if($request->end_date!=""){
 
            $users = $get_days->where('date','<',$request->end_date)->get();
 
          } 
          if((isset($users))){
           
             $record_tax[] = array(                   
                    "days"=>$users,
                     );                 
              
               if(count($users) > 0){
                 $final_data[] = array(
                    "status_code" => '200',
                    'data' => $record_tax,
                  );
                }else{
                    $final_data[] = array(
                        "Data" => 'No Record',
                        
                      );
                }
          }

          else{
            $users = $get_days->get();
          }
            $response = $final_data;  
             
            return $response;
        }
    
      
}
