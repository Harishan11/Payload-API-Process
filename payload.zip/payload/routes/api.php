<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PayloadController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

//user creation
Route::post('/user_creation',[PayloadController::class,'user_creation']);

//login 
Route::post('login',[PayloadController::class,'login']);

//date creation
Route::post('/date_creation',[PayloadController::class,'date_creation']);


//Check Business Day 
Route::post('v1/is_business_day',[PayloadController::class,'is_business_day']);

//Get Business Day
Route::post('v1/get_business_days',[PayloadController::class,'get_business_days']);

